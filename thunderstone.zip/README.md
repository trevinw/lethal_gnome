# Lethal Gnome
A Lethal Company mod that adds the [Gnome sound effect](https://www.youtube.com/watch?v=j3hOd7u35no) to be played ambiently when in the dungeon.